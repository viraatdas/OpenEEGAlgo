matrix = predicted_value;

x = 0;
y = 1;

size_1 = 3528;
size_2 = 3286;

check_1 = 0;
check_2 = 0;

for i = 1:(size_1+size_2)
    if i<size_2
        if matrix(i,1) == x
            check_1=check_1+1;
        end
    else
        if matrix(i,1) == y
            check_2=check_2+1
            check_2
        end 
    end
end

disp ((check_1+check_2)/(size_1+size_2)*100)

          
