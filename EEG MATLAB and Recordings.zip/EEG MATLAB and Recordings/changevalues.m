function matrix = changevalues(matrix)

numeric_response = 4;

matrix = [matrix zeros(size (matrix, 1), 1)];
matrix(matrix(:, 17)==0, 17) = numeric_response;
matrix;c