/*
* The name of the file with the centroids has to be changed within the code editor.
* This file uses row_raw

* The user is asked to input the name of the file with the raw data.
* This file uses row_raw1
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#define N_ROWS_RAW 68
#define N_COLUMNS 14
#define N_ROWS_RAW1 32 //1024*24 = 24576


int get_mode(int nearest_centroid_to_observation[], int size, int max);

int main()
{

    //Centroids are stored in array raw defined by
    //float raw [68][14];
    float raw [N_ROWS_RAW][N_COLUMNS];

//raw[row][*] contains the 14 EEG readings for pizza attribute (size, crust, topping) row.

//Readings from when you thought about ordering a particular kind of pizza (for example, large pan pepperoni) are in array raw1 defined by
//float raw1[1024][14]
    float raw1[N_ROWS_RAW1][N_COLUMNS];
//(You have 24 different files of data you collected when you thought about ordering pizza.  You'll have to repeat this process once for each of those files.
    //float nearest_centroid_to_observation[ii];
    float distance_to_nearest_centroid_for_observation[N_ROWS_RAW1]; // declare this array of float

    //float distance_to_nearest_centroid_for_observation[ii];
    int nearest_centroid_to_observation[N_ROWS_RAW1]; // declare this array of int

    float fileTemp;
    float fileTemp1;

    int row_raw;
    int row_raw1;
    int column;

    int nearest_centroid;
    int distance_to_nearest_centroid;
    int distance;

    char inFileName[] = "AllCrustsSizesToppingsCentroidsFirst64RowsUpdatedWithTomatoTake3.csv"; // The centroids of all the different
    // pizza toppings, crusts, and sizes.

    FILE *inFile;

    /* open the input file */
    inFile = fopen(inFileName, "r");

    for (row_raw = 0; row_raw < N_ROWS_RAW; row_raw++)
    {
        for (column = 0; column < N_COLUMNS; column++)
        {
            fscanf(inFile, "%f", &fileTemp);
            raw[row_raw][column] = fileTemp;
        }
    }

    for (row_raw1 = 0; row_raw1 < N_ROWS_RAW1; row_raw1++)
    {
        for (column = 0; column < N_COLUMNS; column++)
        {
            scanf("%f ", &fileTemp1);
            raw1[row_raw1][column] = fileTemp1;
        }
    }

//To compute the distance between an observation (one row of array raw1), say observation ii,  and a centroid, say, centroid kk, you'll do something like this.

    distance = 0.0;
    for (row_raw1 = 0; row_raw1 < N_ROWS_RAW1; row_raw1++) // I think I needed to add this for loop.
    {
        //for (jj = 0; j < 14; jj++) {
        for (column = 0; column < N_COLUMNS; column++)
        {
            for (row_raw = 0; row_raw < N_ROWS_RAW; row_raw++) //I needed to add this for loop.
            {
                //distance += (raw[kk][jj] - raw1[ii][jj]) ^ 2; // use correct syntax for exponentiation
                //distance += ((raw[row_raw][column] - raw1[row_raw1][column])^2); // use correct syntax for exponentiation
                distance += (((raw[row_raw][column]) - (raw1[row_raw1][column]))*((raw[row_raw][column]) - (raw1[row_raw1][column]))); // use correct syntax for exponentiation
            }
        }
    }

    distance = sqrt(distance);  // use correct name of function for computing square root

    //where you are comparing observation ii and centroid kk.

    //You need to find which centroid is nearest to your observation.

    //for (ii = 0; ii < 1024; ii++)
    for (row_raw1 = 0; row_raw1 < N_ROWS_RAW1; row_raw1++)
    {
        // initially the first centroid is nearest to observation ii
        distance = 0.0;
        //for (kk = 0; kk < 14; kk++) {
        for (column = 0; column < N_COLUMNS; column++)
        {
            //distance += (raw[0][kk] - raw1[ii][kk]) ^ 2;
            //distance += ((raw[0][column] - raw1[row_raw1][column])^2);
            distance += (((raw[0][column]) - (raw1[row_raw1][column]))*((raw[0][column]) - (raw1[row_raw1][column])));
        }
        distance = sqrt(distance);
        nearest_centroid = 0;
        distance_to_nearest_centroid = distance;

        // now see whether any other centroid is nearer to observation ii

        //for (jj = 1; jj < 68; jj++) //looking at remaining 67 centroids
        for (row_raw = 1; row_raw < N_ROWS_RAW; row_raw++)   //looking at remaining 67 centroids
        {

            // compute distance between observation ii and centroid jj
            distance = 0.0;
            //for (kk = 0; kk < 14; kk++)
            for (column = 0; column < N_COLUMNS; column++)
            {
                //distance += (raw[jj][kk] - raw1[ii][kk]) ^ 2;
                //distance += ((raw[row_raw][column] - raw1[row_raw1][column])^2);
                distance += ((raw[row_raw][column] - raw1[row_raw1][column])*(raw[row_raw][column] - raw1[row_raw1][column]));
            }
            distance = sqrt(distance);

            // is centroid jj nearer to observation ii than centroid nearest_centroid ?

            if (distance < distance_to_nearest_centroid)
            {
                //nearest_centroid := jj;
                nearest_centroid = row_raw;
                distance_to_nearest_centroid = distance;
            }
        }

        //nearest_centroid_to_observation[ii] =nearest_centroid; // declare this array of int
        nearest_centroid_to_observation[row_raw1] = nearest_centroid; // declare this array of int

        //distance_to_nearest_centroid_for_observation[ii] = distance; // declare this array of float
        distance_to_nearest_centroid_for_observation[row_raw1] = distance; // declare this array of float

//        printf( "format goes here \n", ii, nearest_centroid_to_observation[ii],
//                                     distance_to_nearest_centroid_for_observation[ii],
//                                    raw1[ii][0], raw1[ii][1], . . . , raw1[ii][13]);
        printf("%d, %d, %f, ", row_raw1, nearest_centroid_to_observation[row_raw1], distance_to_nearest_centroid_for_observation[row_raw1]);

        for (column = 0; column < N_COLUMNS; column++)
        {
            printf("%f, ", raw1[row_raw1][column]);
        }
        printf("\n");
    }
    ////
    //  printf("Mode: %d\n", get_mode(nearest_centroid_to_observation, 1024, 58));
    return 0;
}

////
int
get_mode(
  int nearest_centroid_to_observation[],  /* List of numbers */
  int size, /* Size of list */
  int max   /* Upper range limit */
  )
{
  int *freq;
  int  i;
  int  mode;

  /* Allocate and zero fill a table */
  freq = calloc(max, sizeof *freq);
  /* Increment the appropriate element for each occurance of a[i] */
  for (i = 0; i < 68; i++) {
    ++freq[nearest_centroid_to_observation[i]];
  }
  /* Find the first largest element */
  mode = 0;
  for (i = 0; i < max; i++) {
    if (freq[i] > mode) {
      mode = i;
    }
  }
  //printf("max: %d\n", max);
  free(freq);

  return mode;
}
