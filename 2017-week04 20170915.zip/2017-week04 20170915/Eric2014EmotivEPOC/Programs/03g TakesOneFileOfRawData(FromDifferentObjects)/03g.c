/*
* The program asks the user to input the name of the raw data file.
*/

#include <stdio.h>
#include <math.h>
#include <float.h>
#define N_ROWS    32 //1024 //64 //4 was old value
#define N_COLUMNS 14 // 2 was old value
#define N_CLUSTERS 8 //36 //24 //4 was old value
int main( )
{
    float temp;
    float raw[N_CLUSTERS][N_ROWS][N_COLUMNS];
    float centroid[N_CLUSTERS][N_COLUMNS];
    float distance[N_CLUSTERS];
    int row, column;
    int cluster;

    int nearest[N_CLUSTERS][N_ROWS];
    int frequency[N_CLUSTERS][N_CLUSTERS];

    float centroidDistance[N_CLUSTERS][N_COLUMNS][N_CLUSTERS];
    float centroidDistance1[N_CLUSTERS][N_CLUSTERS];

    int set; /* new variable - since this test program uses same data for training and testing */
    float  min;
    int    minIndex;

    int cluster1;
    int temp1;

    float smallest;
    int columnSmallest;

    /* reading in data captured from headset */

//char inFileName[] = "Crusts.csv";
//
//  FILE *inFile;
//
//  /* open the input file */
//  inFile = fopen(inFileName, "r");

    for (cluster = 0; cluster < N_CLUSTERS; cluster++)
    {
        for (row = 0; row < N_ROWS; row++)
        {
            for (column = 0; column < N_COLUMNS; column++)
            {
                scanf("%f ", &temp);
                  //fscanf(inFile, "%f ", &temp);

                raw[cluster][row][column] = temp;

                /*
                            printf("row: %d col: %d temp: %f raw[row][col]: %f \n", row, column, temp, raw[row][column]);
                */
            }
            /*
                    printf("\n");
            */
        }
    }

    /*
        printf("debugging: input of sensor data\n");
        for (row = 0; row < N_ROWS; row++) {
            for (column = 0; column < N_COLUMNS; column++) {
                printf("%f ", raw[row][column]);
            }
            printf("\n");
        }
        printf("end debugging: input of sensor data\n\n");
    */
    /* computing centroids */

    printf("debugging: computing centroids\n");
    for (cluster = 0; cluster < N_CLUSTERS; cluster++)
    {
        printf("centroid %d:", cluster);
        for (column = 0; column < N_COLUMNS; column++)
        {
            centroid[cluster][column] = 0.0;
        }
        for (row = 0; row < N_ROWS; row++)
        {
            for (column = 0; column < N_COLUMNS; column++)
            {
                centroid[cluster][column] += raw[cluster][row][column];
            }
        }
        for (column = 0; column <N_COLUMNS; column++)
        {
            centroid[cluster][column] /= N_ROWS;
            printf("%4.2f ", centroid[cluster][column]); // "%4.0f " outputs integers, not decimals
        }
        printf("\n");
    }


    for(cluster = 0; cluster < N_CLUSTERS; cluster++)
    {
        for(column = 0; column < N_COLUMNS; column++)
        {
            for(cluster1 = 0; cluster1 < N_CLUSTERS; cluster1++)
            {
                centroidDistance[cluster][column][cluster1] = (centroid[cluster][column]-centroid[(cluster1)][column])
                        * (centroid[cluster][column]-centroid[(cluster1)][column]);
                //printf("%f ", centroidDistance[cluster][column][cluster1]);

            }
            //printf("\n");
        }
        //printf("\n\n");
    }
    printf("\n");

    for(cluster = 0; cluster < N_CLUSTERS; cluster++)
    {
        for(cluster1 = 0; cluster1 < N_CLUSTERS; cluster1++)
        {
            temp1 = 0.0;
            for(column = 0; column < N_COLUMNS; column++)
            {
                temp1 += centroidDistance[cluster][column][cluster1];
            }
            centroidDistance1[cluster][cluster1] = sqrt(temp1);
        }
    }

    for(cluster = 0; cluster < N_CLUSTERS; cluster++)
    {
        smallest = FLT_MAX;
        for(cluster1 = 0; cluster1 < N_CLUSTERS; cluster1++)
        {
            printf("%7.2f ", centroidDistance1[cluster][cluster1]);
            if(centroidDistance1[cluster][cluster1] > 0 && centroidDistance1[cluster][cluster1] < smallest)
            {
                columnSmallest = cluster1;
                smallest = centroidDistance1[cluster][cluster1];
            }
        }
        printf("|| %d %4.2f ", columnSmallest, smallest); //doesn't do ties.
        printf("\n");
    }
    printf("\n");

    //test data and training data

    /* computing distance between object and centroids of known sets of commands */

    for (set = 0; set < N_CLUSTERS; set++)
    {
        for (row = 0; row < N_ROWS; row ++)
        {
            for (cluster = 0; cluster < N_CLUSTERS; cluster ++)
            {
                distance[cluster] =  0.0;

                          printf("row: %d ", row);

                for (column = 0; column < N_COLUMNS; column ++)
                {
                    distance[cluster] += (raw[set][row][column] - centroid[cluster][column])
                                         * (raw[set][row][column] - centroid[cluster][column]);
//                    distance[cluster] += (cluster1[row][column] - centroid[cluster][column])
//                                         * (cluster1[row][column] - centroid[cluster][column]);
                }
                distance[cluster] = sqrt(distance[cluster]);
                printf("%f ", distance[cluster]);
            }
            printf("\n");
            printf("observation %d is recognized as a ", row);
            min = distance[0];
            minIndex = 0;
            for(cluster = 1; cluster < N_CLUSTERS; cluster ++)
            {
                if (distance[cluster] < min)
                {
                    min = distance[cluster];
                    minIndex = cluster;
                }
            }
            printf("member of cluster %d.\n", minIndex); //assign value to nearest above/below this line, subset/subrow
            nearest[set][row] = minIndex;                                         //value will be minIndex
        }
    }

    for (set = 0; set < N_CLUSTERS; set++)
    {

        for(cluster = 0; cluster < N_CLUSTERS; cluster ++)
        {
            frequency[set][cluster] = 0;
        }
        for (row = 0; row < N_ROWS; row ++)
        {
            for (cluster = 0; cluster < N_CLUSTERS; cluster ++)
            {
                frequency[set][nearest[set][row]]+=1;
            }
        }
        printf("frequency ");
        for(cluster = 0; cluster < N_CLUSTERS; cluster ++)
        {
            printf(" %6.2f", 100*((float)(frequency[set][cluster])/((float)N_CLUSTERS*(float)N_ROWS)));
        }
        printf("\n");
    }
    // for each value of set, count how many times the minIndex appears in the array
    // I need another array that's as large as the number of clusters I have.
    return 0;
}
